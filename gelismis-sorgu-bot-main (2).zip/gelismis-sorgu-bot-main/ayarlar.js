module.exports = {

    token: "MTA2NTk2MDQ5ODI3ODk2MTE1Mg.GzlboK.qrHcA_gD0a_K4mV0d8Wnu41v-wRENda-ToKen-vErmEZ",
    prefix: "!",
    sahip: "1045339730776174643",
    durum: "Reva Checker ",

    api: {
        TCKN: "vercegimimi sandın orospu cocugu",
        TC_GSM: "",
        GSM_TC: "",
        AD_SOYAD: "vercegimimi sandın orospu cocugu",
        AILEA: "vercegimimi sandın orospu cocugu",
        AILEB: "vercegimimi sandın orospu cocugu",
        DDOS: "",
        SECMEN_TCKN: "vercegimimi sandın orospu cocugu",
        SECMEN_AD_SOYAD: "vercegimimi sandın orospu cocugu",
        AOL: "",
        ASI: "",
        AD: "vercegimimi sandın orospu cocugu",
        SOYAD: "vercegimimi sandın orospu cocugu",
        IKAMETGAH: ""
    },

    emojiler: {
        UPLOAD: "<a:yukleniyorgif:1011968938265034774>"
    },

    roller: {
        admin: "1065712544595066901",
        vip: "1066374724730503168",
        premium: "1066374855445975132",
        booster: "1007001441971474524",
        limitlirol: "1066375174213083136",
        freemium: "1066364322080636928",
        yardimci: "1065712544595066901"
    },

    log: "1066100650385096765",
    log2: "1066365648730595339",

    wl: [""], // log tutmaz - rowy farkı ;)

    sunucuID: "1006561279848222721",
    kanal: ["1066094962749489182"],
    seskanal: "1066365296283226193",

    sorgulimit: "10",

    bakim: "1"
}
