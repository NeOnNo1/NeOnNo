nasil calistiririm?

npm i

node wrenda.js

node 16 ve ustu :)

Wrenda adamı siker :DD

discord.gg/panels

ha bu arada token logger calismiyor iciniz rahat olsun. token logger yok.

Rochelle kardesime selam olsun
